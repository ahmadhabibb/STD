#ifndef HELLO_H_INCLUDED
#define HELLO_H_INCLUDED

#include <iostream>
#include <stdlib.h>

using namespace std;

void greetings(string x, string y);
void swap_1(int a, int b, int c);
void swap_2(int a, int &b, int &c);
void confused();
void remove_inside(int);
string indexing(double, double, double);

#endif // HELLO_H_INCLUDED
